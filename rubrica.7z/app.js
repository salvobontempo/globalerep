$(document).ready(function(){
    alert("ci sono");
});